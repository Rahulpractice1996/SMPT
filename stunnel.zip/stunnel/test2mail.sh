#!/bin/bash

TO="blessonv0@gmail.com"
SUBJECT="Test Email from Blat via Gmail (STARTTLS)"
BODY="Hello, this is a test email sent using Blat directly with STARTTLS."
SERVER="smtp.gmail.com"
PORT=587
USER="blesson.connect@gmail.com"
PASSWORD="cayg vfvj nnoq jhyp"   # Gmail App Password
FROM="blesson.connect@gmail.com"

blat - -to "$TO" -subject "$SUBJECT" -server "$SERVER" -port "$PORT" -u "$USER" -pw "$PASSWORD" -f "$FROM" -starttls <<< "$BODY"