#!/bin/bash

TO="blessonv0@gmail.com"
SUBJECT="Test Email from Blat via Gmail"
BODY="Hello, this is a test email sent using Blat and Gmail via Stunnel."
SERVER="localhost"
PORT=465
USER="blesson.connect@gmail.com"
PASSWORD="cayg vfvj nnoq jhyp"
FROM="blesson.connect@gmail.com"

echo "$BODY" | /c/blat/full/blat.exe - -to "$TO" -subject "$SUBJECT" -server "$SERVER" -port "$PORT" -u "$USER" -pw "$PASSWORD" -f "$FROM"